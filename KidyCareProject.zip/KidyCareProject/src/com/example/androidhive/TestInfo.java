package com.example.androidhive;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

//import com.example.androidhive.MainActivity.CreateAccount;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
//import android.view.Menu;
//import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import static java.lang.Math.pow;


public class TestInfo extends Activity {
	private ProgressDialog pDialog;

	JSONParser jsonParser = new JSONParser();
	
	// url to create new product
	 	private static String url_register = "http://192.168.56.1/Trial/addtest.php";
	 	
	 // JSON Node names
	 	private static final String TAG_SUCCESS = "success";
	 	
	 	
 EditText idpatient, patientname, weight, age, docterid, cretlel;
    RadioGroup sex;
    RadioButton f, m;
    Button compute,bluetoothDevice;
    String patientName, weigh, patientage, cretinineLevel, docName, gender, result;
    int weightlvl, age_patient;
    double crtlvl, eGFR;
    int value=0;
    Context context1 = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_info);

        patientname = (EditText) findViewById(R.id.name);
        weight = (EditText) findViewById(R.id.wght);
        age = (EditText) findViewById(R.id.age);
        sex = (RadioGroup) findViewById(R.id.radgrp);
        f=(RadioButton) findViewById(R.id.female);
        m =(RadioButton) findViewById(R.id.male);
        cretlel = (EditText) findViewById(R.id.crl);
        //docterid = (EditText) findViewById(R.id.docter_id);
       
        compute =(Button) findViewById(R.id.comp);
        bluetoothDevice =(Button) findViewById(R.id.btnBluetooth);
        
        
        f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                value =1;
            }
        });
        bluetoothDevice.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				try{
				Intent intent=new Intent(getBaseContext(),BluetoothActivity.class);
				
			startActivity(intent);
				
				Bundle extra = getIntent().getExtras();
				crtlvl=extra.getDouble("value");
				
				
			
				cretinineLevel=Double.toString(crtlvl);
				age.setText(cretinineLevel);
			  	Toast.makeText(getApplicationContext(), "Value: "+cretinineLevel, Toast.LENGTH_LONG).show();
			    
				}
				catch(Exception e){
				 	e.printStackTrace();
					
				}
			}
		});
        

        compute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

try{
             
             //   docName = docterid.getText().toString();
//                cretinineLevel = cretlel.getText().toString();
//                crtlvl = Double.parseDouble(cretinineLevel);

            	new CreateAccount().execute();

                //check if all fields are filled
              


            }catch(Exception e){
            	e.printStackTrace();
            	
            }
        }
        });

    }

    /**
  	 * Background Async Task to Create new product
  	 * */
  	class CreateAccount extends AsyncTask<String, String, String> {

  		/**
  		 * Before starting background thread Show Progress Dialog
  		 * */
  		@Override
  		protected void onPreExecute() {
  			super.onPreExecute();
  			pDialog = new ProgressDialog(TestInfo.this);
  			pDialog.setMessage("Creating Account..");
  			pDialog.setIndeterminate(false);
  			pDialog.setCancelable(true);
  			pDialog.show();
  		}

  		/**
  		 * Creating product
  		 * */
  		protected String doInBackground(String... args) {
  	       //get data from user
         patientName = patientname.getText().toString();
            weigh = weight.getText().toString();
            weightlvl = Integer.parseInt(weigh);
            patientage = age.getText().toString();
            age_patient = Integer.parseInt(patientage);
//            docName = docterid.getText().toString();
            cretinineLevel = cretlel.getText().toString();
            crtlvl = Double.parseDouble(cretinineLevel);
            try{    
            //check if all fields are filled
            if (patientname.equals("")&&weight.equals("")&&age.equals("")&&docterid.equals("")&&cretlel.equals("")) {
               Toast.makeText(getBaseContext(), "Please fill all the fields", Toast.LENGTH_SHORT).show();
                //Reset text if pass was not matching
//                cr.setText("");
//                z.setText("");
//                p.setText(" ");


               
            }     else {
            	
           	 if(value==1){
                    gender = "Female";
                      eGFR =  186 * pow((crtlvl / 88.4), -1.154) * pow(age_patient,-0.203) * (0.742 ) * (1.210 );
                      result = Double.toString(eGFR);

                		// Building Parameters
               			List<NameValuePair> params = new ArrayList<NameValuePair>();
               			params.add(new BasicNameValuePair("patientName", patientName));
               			params.add(new BasicNameValuePair("weigh", weigh));
               			params.add(new BasicNameValuePair("patientage", patientage));
               			params.add(new BasicNameValuePair("gender", gender));
               			params.add(new BasicNameValuePair("cretinineLevel",cretinineLevel));
               			params.add(new BasicNameValuePair("result",result));

               			// getting JSON Object
               			// Note that create product url accepts POST method
               			JSONObject json = jsonParser.makeHttpRequest(url_register,
               					"POST", params);
               			
               			// check log cat fro response
               			Log.d("Create Response", json.toString());

               			// check for success tag
              			try {
              				int success = json.getInt(TAG_SUCCESS);

              				if (success == 1) {
              					// successfully created product
              					Intent i = new Intent(getApplicationContext(), LogIn.class);
              					startActivity(i);
              					
              					// closing this screen
              					finish();
              				} else {
              					// failed to create product
              				}
              			} catch (JSONException e) {
              				e.printStackTrace();
              			}
              			
                      
                  }
                  else {
                    gender = "Male";
                      eGFR =  186 * pow((crtlvl / 88.4), -1.154) * pow(age_patient,-0.203) * (1.210 );
                      result = Double.toString(eGFR);

                		// Building Parameters
               			List<NameValuePair> params = new ArrayList<NameValuePair>();
               			params.add(new BasicNameValuePair("patientName", patientName));
               			params.add(new BasicNameValuePair("weigh", weigh));
               			params.add(new BasicNameValuePair("patientage", patientage));
               			params.add(new BasicNameValuePair("gender", gender));
               			params.add(new BasicNameValuePair("cretinineLevel",cretinineLevel));
               			params.add(new BasicNameValuePair("result",result));

               			// getting JSON Object
               			// Note that create product url accepts POST method
               			JSONObject json = jsonParser.makeHttpRequest(url_register,
               					"POST", params);
               			
               			// check log cat fro response
               			Log.d("Create Response", json.toString());

               			// check for success tag
              			try {
              				int success = json.getInt(TAG_SUCCESS);

              				if (success == 1) {
              					// successfully created product
              					Intent i = new Intent(getApplicationContext(), LogIn.class);
              					startActivity(i);
              					
              					// closing this screen
              					finish();
              				} else {
              					// failed to create product
              				}
              			} catch (JSONException e) {
              				e.printStackTrace();
              			}
              			
                      
                  }
                  value =0;
                  gender = "";
                  
                  

           }
            }catch(Exception e){
            	e.printStackTrace();
            	
            }
            
            
            
            return null;
		}

  		/**
  		 * After completing background task Dismiss the progress dialog
  		 * **/
  		protected void onPostExecute(String file_url) {
  			// dismiss the dialog once done
  			pDialog.dismiss();
  		}

  	}
  
}
