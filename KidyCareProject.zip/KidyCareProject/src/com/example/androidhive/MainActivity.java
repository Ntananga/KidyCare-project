package com.example.androidhive;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity {
	// Progress Dialog
		private ProgressDialog pDialog;

		JSONParser jsonParser = new JSONParser();
		
    EditText num, userName, pass, confirmPassword;
    
    Button reg;
    
 // url to create new product
 	private static String url_register = "http://192.168.56.1/Trial/create_product.php";
 	
 // JSON Node names
 	private static final String TAG_SUCCESS = "success";
 	
    //String variable to get the values
//    String name, user_name, user_pass, confirm_pass;
   // Context context1 = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num = (EditText) findViewById(R.id.docName);
        userName = (EditText) findViewById(R.id.reg_user);
        pass = (EditText) findViewById(R.id.pass_user);
//        confirmPassword = (EditText) findViewById(R.id.con_pass);
        reg = (Button) findViewById(R.id.reg_button);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            	// creating new product in background thread
				new CreateAccount().execute();
				
                
//
//                //check if password match
//                if (num.equals("")&&userName.equals("")&&pass.equals("")&&confirmPassword.equals("")) {
//                   
//                 	Toast.makeText(getBaseContext(), "Please Fill all the fields", Toast.LENGTH_SHORT).show(); 
//
//                } else {
//                	
//                	 if(!pass.equals(confirmPassword)){
//
//                         Toast.makeText(getBaseContext(), "Password Don't match", Toast.LENGTH_SHORT).show();
//                         //Reset text if pass was not matching
//                         userName.setText("");
//                         pass.setText("");
//                         confirmPassword.setText(" ");
//                         
//                     }else{
//                     
//
////                      Toast.makeText(getBaseContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
////                    Intent intent = new Intent(getBaseContext(), TestInfo.class);
////                    startActivity(intent);
//                     } 
//                }
     }
        });
    }

    /**
	 * Background Async Task to Create new product
	 * */
	class CreateAccount extends AsyncTask<String, String, String> {

		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(MainActivity.this);
			pDialog.setMessage("Creating Account..");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();
		}

		/**
		 * Creating product
		 * */
		protected String doInBackground(String... args) {
			//get data from user
            String name = num.getText().toString();
            String username = userName.getText().toString();
            String password = pass.getText().toString();
//            String confirm_pass = confirmPassword.getText().toString();

			// Building Parameters
			List<NameValuePair> params = new ArrayList<NameValuePair>();
			params.add(new BasicNameValuePair("name", name));
			params.add(new BasicNameValuePair("username", username));
			params.add(new BasicNameValuePair("password", password));

			// getting JSON Object
			// Note that create product url accepts POST method
			JSONObject json = jsonParser.makeHttpRequest(url_register,
					"POST", params);
			
			// check log cat fro response
			Log.d("Create Response", json.toString());

			// check for success tag
			try {
				int success = json.getInt(TAG_SUCCESS);

				if (success == 1) {
					// successfully created product
					Intent i = new Intent(getApplicationContext(), LogIn.class);
					startActivity(i);
					
					// closing this screen
					finish();
				} else {
					// failed to create product
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}

			return null;
		}

		/**
		 * After completing background task Dismiss the progress dialog
		 * **/
		protected void onPostExecute(String file_url) {
			// dismiss the dialog once done
			pDialog.dismiss();
		}

	}
  
}
